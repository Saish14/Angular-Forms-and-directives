import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Directives';
  Courses = [1,2,3];
  viewMode: string ='map';
  teams = [
    {Id: 1 , name: 'India'},
    {Id: 2 , name: 'Australia'},
    {Id: 3 , name: 'England'}
  ];

  addTeams()
  {
    this.teams.push({Id: 4 , name: 'New-Zealand'});
  }

  removeTeams(team)
  {
    let index = this.teams.indexOf(team);
    this.teams.splice(index , 1);
  }
}
